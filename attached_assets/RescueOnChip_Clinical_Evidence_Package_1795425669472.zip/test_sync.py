"""Offline software/parser tests using explicitly fabricated *test fixtures* only."""
import sqlite3
import unittest
from pathlib import Path
from sync_public_evidence import extract_trial

HERE=Path(__file__).parent
class TestTemplate(unittest.TestCase):
    def test_database_template_is_research_only(self):
        db=sqlite3.connect(HERE/'clinical_evidence_sources.sqlite')
        self.assertEqual(db.execute('SELECT classification FROM clinical_use_policy').fetchone()[0],'RESEARCH_ONLY')
        self.assertEqual(db.execute('SELECT COUNT(*) FROM source_catalog').fetchone()[0],21)
        db.close()
    def test_trial_parser(self):
        fixture={'protocolSection':{'identificationModule':{'nctId':'NCT_TEST_ONLY','briefTitle':'Fixture'},
                  'statusModule':{'overallStatus':'COMPLETED'},
                  'designModule':{'phases':['PHASE3'],'enrollmentInfo':{'count':123}},
                  'armsInterventionsModule':{'interventions':[{'name':'test medicine'}]},
                  'conditionsModule':{'conditions':['test condition']}},
                  'resultsSection':{'outcomeMeasuresModule':{'outcomeMeasures':[{'type':'PRIMARY','title':'test outcome'}]}}}
        a=extract_trial(fixture)
        self.assertEqual(a['nct_id'],'NCT_TEST_ONLY')
        self.assertEqual(a['enrollment'],123)
        self.assertEqual(len(a['outcomes']),1)
        self.assertTrue(a['has_results'])
if __name__=='__main__': unittest.main()
